package pharmacyinventorymanager;

/**
 * Keeps three integer fields to keep track of the day, month, and year for a 
 * given date; including, verifying whether the fields correspond to a valid
 * date.
 * @author Tom
 */
public class Date 
{
    private int day;
    private int month;
    private int year;
    
    /**
     * Sets the default date to the current date.
     */
    public Date()
    {
    	//default
    	java.util.Date date = new java.util.Date();
        day = date.getDate();
        month = date.getMonth() + 1;
        year = date.getYear() + 1900;
    }
    
    /**
     * Getter for the day field.
     * @return the day in this date
     */
    public int getDay()
    {
        return day;
    }
    
    /**
     * Getter for the month field.
     * @return the month in this date
     */
    public int getMonth()
    {
        return month;
    }
    
    /**
     * Getter for the year field.
     * @return the year in this date
     */
    public int getYear()
    {
        return year;
    }
    
    /**
     * Check if the given year is a leap year.
     * @param year the year to be tested
     * @return whether the year is a leap year or not
     */
    private boolean isLeapYear(int year)
    {
        if(year % 400 == 0)
            return true;
        else if(year % 100 == 0)
            return false;
        else if(year % 4 == 0)
            return true;
        return false;
    }
    
    /**
     * Checks if the date is a valid date in the standard calendar system used today.
     * @param day the day for this date
     * @param month the month for this date
     * @param year the year for this date
     * @return whether the date is valid or not from the given fields
     */
    private boolean isValidDate(int day, int month, int year)
    {
        if(year < 0)
        {
            System.err.println("Invalid year: " + year);
            return false;
        }
        if(day < 1)
        {
            System.err.println("Invalid day: " + day);
            return false;
        }
        if(month < 1 || month > 12)
        {
            System.err.println("Invalid month: " + month);
            return false;
        }
        
        if((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) && day < 32)
            return true;
        if(month == 2)
        {
            if(isLeapYear(year))
            {
                if(day < 30)
                    return true;
            }
            else
            {
                if(day < 29)
                    return true;
            }
        }
        if((month == 4 || month == 6 || month == 9 || month == 11) && day < 31)
            return true;
        
        System.err.println("Invalid day: " + day);
        return false;        
    }
    
    /**
     * Sets the date for this instance
     * @param day   day field
     * @param month month field
     * @param year year field
     * @return whether the date is valid or not
     */
    public boolean setDate(int day, int month, int year)
    {
        if(isValidDate(day, month, year))
        {
            this.day = day;
            this.month = month;
            this.year = year;
            return true;
        }
        return false;
    }
    
    /**
     * Returns a string of the date (dd/mm/yyyy)
     * @return a string of the date (dd/mm/yyyy)
     */
    public String toString()
    {
        return (Integer.toString(day) + "/" + Integer.toString(month) + "/" + Integer.toString(year));
    }
}
