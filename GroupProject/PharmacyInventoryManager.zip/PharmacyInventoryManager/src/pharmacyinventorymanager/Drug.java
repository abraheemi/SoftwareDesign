package pharmacyinventorymanager;

/**
 * A drug with a quantity and expiration date in the pharmacy inventory.
 */
public class Drug 
{
    private String name;
    private int quantity;
    private Date expiry;
    
    /**
     * Constructor for a new Drug object that sets name, quantity and expiry 
     * to the String name, int quantity and Date expiry parameters
     * 
     * @param name			A string that contains the name of the drug
     * @param quantity		An int that contains how much of the drug there is
     * @param expiry		A date object that contains the expiration date of the Drug
     */
    public Drug(String name, int quantity, Date expiry)
    {
        this.name = name;
        this.quantity = quantity;
        this.expiry = expiry;
    }
    
    /**
     * A name Getter that returns the name field of the drug
     * 
     * @return				A string containing the name field
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * A quantity Getter that returns the quantity field of the drug
     * 
     * @return				An int containing the quantity field
     */
    public int getQuantity()
    {
        return quantity;
    }
    
    /**
     * A Date Getter that returns the expiry field of the drug
     * 
     * @return				A Date object containing the expiry field
     */
    public Date getDate()
    {
        return expiry;
    }
    
    /**
     * A Date Getter that returns the expiry field of the drug as a string
     * 
     * @return				A string containing the expiry field
     */
    public String getDateString()
    {
        return expiry.toString();
    }
    
    /**
     * A name field Setter that sets the field to the name parameter
     * 
     * @param name			A string that contains the name of the Drug
     */
    public void setName(String name)
    {
        this.name = name;
    }
        
    /**
     * Increments the quantity of the drug by the quantity parameter
     * 
     * @param quantity		An int that contains the amount to increment the
     * 							the drug quantity by
     */
    public void addQuantity(int quantity)
    {
        this.quantity += quantity;
    }
    
    /**
     * Decrements the quantity of the drug by the quantity parameter
     * If drug demand is higher than drug stock, stock becomes 0
     * (the drug becomes sold out)
     * 
     * @param quantity		An int that contains the amount to decrement the
     * 							the drug quantity by
     */
    public void subtractQuantity(int quantity)
    {
        if(this.quantity >= quantity)
            this.quantity -= quantity;
        else
        	this.quantity = 0; // Drug becomes sold out
    }
    
}
