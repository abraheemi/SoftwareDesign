package pharmacyinventorymanager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Inventory Class implements Subject interface.
 * 
 * The Inventory class is a concrete subject in the Observer pattern and a singleton.
 * It contains the pharmacy's drug inventory as an ArrayList of Drug objects, the list 
 * of observers, an iterator, and the current date.
 * 
 * @version 1.0
 * @author Joey
 *
 */
public class Inventory implements Subject
{
    private static Inventory inventory;
    private ArrayList<Drug> drugList;
    private ArrayList<Observer> observers;
    private ArrayListIterator iter;
    private Date currentDate;

    /**
     * Private Inventory Constructor.
     * No parameters, defaults to an empty inventory with no observers and the 
     * default date. Private so only Inventory class can call it, adhering to
     * the singleton pattern.
     */
    private Inventory()
    {
        drugList = new ArrayList<Drug>();
        observers = new ArrayList<Observer>();
        currentDate = new Date();
    }

    /**
     * returns the instance of inventory, creating a new instance if it does not
     * yet exist
     * 
     * @return the only instance on Inventory
     */
    public static Inventory getInstance()
    {
        if(inventory == null)
            inventory = new Inventory();
        return inventory;
    }
    
    /**
     * set the current date
     * 
     * @param day	the day of the month
     * @param month	integer value for the month(1-12)
     * @param year	year
     */
    public void setDate(int day, int month, int year)
    {
        currentDate.setDate(day, month, year);
    }

    /**
     * Checks if the drug name is in the list.
     * 
     * @param name name of the drug
     * @param date the expiration date
     * @return the position of where the drug is
     */
    public int isInList(String name, Date date)
    {
        iter = new ArrayListIterator(drugList);
        Drug drug;

        int i = 0;
        while(iter.hasNext())
        {
            drug = iter.next();
            if(drug.getName().equals(name) && drug.getDate().getDay() == date.getDay() && drug.getDate().getMonth() == date.getMonth() && drug.getDate().getYear() == date.getYear())
                return i;
            i++;
        }
        return -1;
    }

    /**
     * adds a new supply of a drug to the inventory
     * 
     * @param name		name of the drug
     * @param quantity	amount of the drug
     * @param expiry	expiration date of the drug
     */
    public void addDrug(String name, int quantity, Date expiry)
    {
        int i = isInList(name, expiry);

        if(i >= 0)
        {
            drugList.get(i).addQuantity(quantity);
        }
            else
        {
            Drug newDrug = new Drug(name, quantity, expiry);
            drugList.add(newDrug);
        }
    }
    
    /**
     * removes a quantity of some drug from the inventory
     * 
     * @param name		name of the drug
     * @param quantity	quantity to be removed
     * @param expiry	expiration date of the drug
     */
    /*
    public void removeDrug(String name, int quantity, Date expiry)
    {
        int i = isInList(name, expiry);
        if(i >= 0)
        {
            if(quantity <= drugList.get(i).getQuantity())
                drugList.get(i).subtractQuantity(quantity);
        }
            
    }*/
    
    /**
     * Sorts the array list of drugs in ascending order based on expiration year
     * then iterates the array list until it reaches the first occurrence of the drug.
     * Since the array list is sorted, we know that the drug with the nearest expiration
     * date will be removed.
     * 
     * @param name
     * @return
     */
    public int isInList(String name)
    {
        iter = new ArrayListIterator(drugList);     
        Collections.sort(drugList, new CompareDates());
        Drug drug;

        int i = 0;
        while(iter.hasNext())
        {
            drug = iter.next();
            if( drug.getName().equals(name))
                return i;
            i++;
        }
        return -1;
    }
    
    /**
     * Subtracts the quantity from a given drug name
     * 
     * @param name
     * @param quantity
     */
    public void removeDrug(String name, int quantity)
    {
    	int i = isInList(name);
    	int requested_quantity = quantity;
        int removed_quantity = 0;
    	while(i >= 0){
    		// Remove drug. Then checks if another drug with same name exists
    		// but different expiration date
    		if( quantity >= drugList.get(i).getQuantity() ){
    			quantity -= drugList.get(i).getQuantity();
    			removed_quantity += drugList.get(i).getQuantity();
    			drugList.remove(i); // Remove drug completely 		
    		}
    		else{
    			// Subtract drug and exit loop
    			drugList.get(i).subtractQuantity(quantity);
    			removed_quantity += quantity;
    			break;
    		}
    		
    		// Is there another drug with same name but different date?
    		i = isInList(name); 
    	}
    	if(removed_quantity < requested_quantity){
    		System.out.println("Error: Only " + removed_quantity + " " + name + " available.");
    	}
    }
    
    /*
    public void removeDrug(String name, int quantity){
    	int i = isInList(name);
        
    	while(i >= 0){
    		// Remove drug. Then checks if another drug with same name exists
    		// but different expiration date
    		if( quantity >= drugList.get(i).getQuantity() ){
    			quantity -= drugList.get(i).getQuantity();
    			drugList.remove(i); // Remove drug completely   			
    		}
    		else{
    			// Subtract drug and exit loop
    			drugList.get(i).subtractQuantity(quantity);
    			break;
    		}
    		
    		// Is there another drug with same name but different date?
    		i = isInList(name); 
    	}
 
    }
    */
    
    /**
     * Print the name, quantity, and expiration date of all drugs in the 
     * inventory to standard output.
     */
    public void displayInventory()
    {
        
        iter = new ArrayListIterator(drugList);
        //Collections.sort(drugList, new CompareDates());
        Collections.sort(drugList, new CompareNames());
        Drug drug;
        int i = 1;
        System.out.println("Drug Inventory");
        //System.out.println("ID:\tName:\t\t\tQuantity\tExpiry Date:");
        System.out.println("ID:\tQuantity\tExpiry Date:\tName");
        System.out.println("ID:\t--------\t------------\t----");
        while(iter.hasNext())
        {
            drug = iter.next();
            //System.out.println(i + ")\t" + drug.getName() + "\t\t\t" + drug.getQuantity() + "\t\t" + drug.getDate().getDay() + "/" + drug.getDate().getMonth() + "/" + drug.getDate().getYear());
            System.out.println(i + ")\t" + drug.getQuantity() + "\t\t" + drug.getDate().getDay() + "/" + drug.getDate().getMonth() + "/" + drug.getDate().getYear() + "\t" + drug.getName());
            ++i;
        }
        
    }
    
    /**
     * adds an observer to the list of observers
     * 
     * @param o	the observer to be added
     */
    public void registerObserver(Observer o)
    {
        observers.add(o);
    }

    /**
     * removes an observer from the list of observers
     * 
     * @param o	the observer to be removed
     */
    public void removeObserver(Observer o)
    {
        int i = observers.indexOf(o);
        if(i >= 0)
            observers.remove(i);
    }

    /**
     * calls the update method of each observer on every drug in the inventory. 
     */
    public void notifyObservers()
    {
        for(int i = 0; i < observers.size(); i++)
        {
            Observer observer = (Observer)observers.get(i);

            iter = new ArrayListIterator(drugList);
            Drug drug;
            while(iter.hasNext())
            {
                drug = iter.next();
                observer.update(drug, currentDate);
            }
        }
    }
}

/**
 * Compares dates
 */
class CompareDates implements Comparator<Drug>
{

	@Override
        /**
         * Compares expiration dates of drugs
         * @return which drug expires first
         */
	public int compare(Drug e1, Drug e2) 
        {
		if(e1.getDate().getYear() > e2.getDate().getYear())
			return 1;
		else
			return -1;
	}
	
}

/**
 * Compares names of drugs
 */
class CompareNames implements Comparator<Drug>
{
	@Override
        /**
         * Compares names of drugs
         * @param e1 drug 1
         * @param e2 drug 2
         * @return whether the drug is the same name or not
         */
	public int compare(Drug e1, Drug e2) {
		if(e1.getName().compareToIgnoreCase(e2.getName()) > 0)
			return 1;
		else
			return -1;
	}
	
}
