package pharmacyinventorymanager;

/**
 * General Observer interface of observers to be notified
 */
public interface Observer 
{
    /**
     * Updates observers
     * @param drug the specified drug
     * @param date the expiration date
     */
    public void update(Drug drug, Date date);
}
