package pharmacyinventorymanager;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * The pharmacy inventory manager that keeps track of an inventory of drugs.
 * Takes in user input to modify the stock.
 * @author Tom & Abraheem
 */
public class PharmacyInventoryManager
{
	/**
	 * Prints help menu containing all valid commands
	 * 
	 */
    private static void printCommands()
    {
        System.out.println("Please enter a command:");
        System.out.println("1 - Add drug");
        System.out.println("2 - Subtract drug");
        System.out.println("3 - Display drug inventory");
        System.out.println("4 - Verify stock");
        System.out.println("5 - Change current date");
        System.out.println("6 - Help");
        System.out.println("7 - Input from file");
        System.out.println("x - quit");
    }
 
    /**
     * Checks quantity to make sure it's not less than 1
     * 
     * @param qty		Drug quantity from user input
     */
    private static void checkQuantity(int qty){
    	if(qty < 1){
    		System.out.println("*** Error: Quantity must be larger than 0 ***");
    	}
    }
    
    /**
     * Main method used by client. 
     * Displays menu and takes user input.
     */
    public static void main(String args[]) 
    {
        Inventory inventory = Inventory.getInstance();
        DisplayExpiry expiryDisplay = new DisplayExpiry();
        DisplayOutOfStock OFSDisplay = new DisplayOutOfStock();
        //Date currentDate =  new Date();
        int day, month, year;
        String name, dateString, fileName;
        int quantity;
        Date date;
        StringTokenizer token;
        
        inventory.registerObserver(expiryDisplay);
        inventory.registerObserver(OFSDisplay);
        
        Scanner in = new Scanner(System.in);        
        System.out.println("Welcome to the Pharmacy Inventory Manager!");
        printCommands();
        
        char input;
        String line;
        while(true)
        {
            System.out.print("Command: ");
            line = in.next();
            input = line.charAt(0);
            
            switch (input) {
            case '1': // Add drug
                date = new Date();
                
                System.out.println("Enter name of drug: ");
                in.nextLine(); // Flush out the newline character
                name = in.nextLine(); // Take name even if it contains more than one word like (Tylenol PM)

                do{ // Prompt for quantity until input is correct
                	System.out.println("Enter amount of drug to add: ");
                	quantity = in.nextInt();
                	checkQuantity(quantity); // Make sure quantity is a valid number
                } while(quantity < 1);
                
                do{ // Prompt for date until input is correct
	                System.out.println("Enter expiry date(dd/mm/yyyy): ");
	                dateString = in.next(); // The entire date string
	                
	                token = new StringTokenizer(dateString); // Splits dateString into tokens
	                day = Integer.parseInt(token.nextToken("/"));
	                month = Integer.parseInt(token.nextToken("/"));
	                year = Integer.parseInt(token.nextToken("/"));
	                
                } while( ! date.setDate(day, month, year) ); // Checks date. If valid, set date, else re-prompt
	                
                inventory.addDrug(name, quantity, date); // Creates a drug object
                inventory.notifyObservers();
                
                break;
            case '2': // Subtract drug (sell drug)
                System.out.print("Enter name of drug: ");
                in.nextLine(); // Flush out the newline character
                name = in.nextLine(); // Take name even if it contains more than one word
                //System.out.println("Name: " + name); // DEBUG
                System.out.print("Enter amount of drug to subtract: ");
                quantity = in.nextInt(); 
          
                inventory.removeDrug(name, quantity);
                inventory.notifyObservers();
                
                break;
            case '3': // Display inventory
                inventory.displayInventory();
                
                break;
            case '4': // Check for low quantity or expiring drugs (This is the observer part)
                inventory.notifyObservers();
                
                break;
            case '5': // Change current system date
                System.out.println("Enter current date(dd/mm/yyyy): ");
                dateString = in.next(); // The entire date string
                token = new StringTokenizer(dateString, "/"); // Splits dateString into tokens          
                inventory.setDate(	Integer.parseInt(token.nextToken()), 
                					Integer.parseInt(token.nextToken()), 
                					Integer.parseInt(token.nextToken()));
                
                break;
            case '6': // Print help menu
                printCommands();
                
                break;
            case '7': // Take input from a file
            	System.out.print("Enter file name: ");
            	fileName = in.next(); // Gets file name from stdin
				
		try {
			FileReader fileReader = new FileReader(fileName); // Create file reader
		Scanner buff = new Scanner(fileReader); // Create scanner to traverse the file
			// While not end of file, read and add all contents of file to inventory
				while( buff.hasNext() ){ // While file is not empty
						date = new Date();
						name = buff.nextLine();
						quantity = buff.nextInt();
						
						dateString = buff.next();
		                token = new StringTokenizer(dateString);
		                day = Integer.parseInt(token.nextToken("/"));
		                month = Integer.parseInt(token.nextToken("/"));
		                year = Integer.parseInt(token.nextToken("/"));
		                date.setDate(day, month, year);
		                
		                inventory.addDrug(name, quantity, date);
		                if( ! buff.hasNext() ){ // Exits the while loop before last flush. It would crash otherwise.     
		                	break;
		                }
		                buff.nextLine(); // Flush out the newline character
					}
					buff.close();
				} 
				catch (FileNotFoundException ex) {
					System.out.println("Unable to open file '" + fileName + "'");
				}
				
            	break;
            case 'x': // Exit program
            	in.close();
            	System.out.println("Exiting Program...");
                System.exit(0);
                
            default: // Invalid user input
                System.out.println("Invalid command!");
                printCommands();
                break;
            } // SWITCH
        } // WHILE
    } // MAIN
} // CLASS