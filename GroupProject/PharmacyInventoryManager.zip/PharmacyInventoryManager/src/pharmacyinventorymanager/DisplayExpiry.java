package pharmacyinventorymanager;

/**
 * DisplayExpiry class implements Observer interface.
 * 
 * DisplayExpiry is a concrete observer that displays a warning if any of the drug inventory has
 * expired or is about to expire.
 *
 * @version	1.0
 * @author	Joey
 */
public class DisplayExpiry implements Observer
{
	/**
	 * update method defined in Observer interface.
	 * Prints a warning to standard output if the drug has expired or will expire in the next 7 days.
	 * 
	 * @param drug	The drug to be checked
	 * @param date	The current date
	 */
    public void update(Drug drug, Date date)
    {
    	int expiryDate = getJDN(drug.getDate());
    	int currDate = getJDN(date);
    	int diff = expiryDate - currDate;
    	if(diff <= 0)
    	{
    		System.out.println(drug.getName() + " has expired!");
    	}
    	else if(diff <= 7)
        {
        	System.out.println(drug.getName() + " will expire soon!\nOnly " + diff + " days left!");
        }
    }
    
    /**
     * getJDN method
     * returns an integer Julian Day Number corresponding to the given date.
     * http://en.wikipedia.org/wiki/Julian_day
     * 
     * @param date	The date to be converted
     * @return		The integer Julian Day Number
     */
    private int getJDN(Date date)
    {
    	int a = (14-date.getMonth())/12;
    	int y = date.getYear() + 4800 - a;
    	int m = date.getMonth() + 12*a - 3;
    	int jdn = date.getDay() + (153*m+2)/5 + 365*y + y/4 - y/100 + y/400 - 32045;
    	return jdn;
    }
}
