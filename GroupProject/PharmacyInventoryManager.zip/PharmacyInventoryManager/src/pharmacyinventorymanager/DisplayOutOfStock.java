package pharmacyinventorymanager;

/**
 * The concrete observer that notifies the user when a drug is almost out of
 * stock (less than or equal to five drugs in stock).
 */
public class DisplayOutOfStock implements Observer
{
    public void update(Drug drug, Date date)
    {
        if(drug.getQuantity() <= 5)
        {
            System.out.println(drug.getName() + " is running out!\nOnly " + drug.getQuantity() + " left!");
        }
    }
}
