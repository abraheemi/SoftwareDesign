package pharmacyinventorymanager;

/**
 * The subject interface that notifies the observers    
 */
public interface Subject 
{
	/**
	 * Registers subject to observers  to be notified
	 * 
	 * @param o		observer object that the subject will be registered to 
	 */
    public void registerObserver(Observer o);
    
    /**
     * Removes Subject from observers so they are not notified
     * 
     * @param o		observer object that Subject will be removed from
     */
    public void removeObserver(Observer o);
    
    /**
     * Notifies the Subject when the observer class finds a certain state
     */
    public void notifyObservers();
}
