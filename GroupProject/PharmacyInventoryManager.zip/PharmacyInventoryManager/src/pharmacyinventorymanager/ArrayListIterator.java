package pharmacyinventorymanager;

import java.util.ArrayList;

/**
 * Iterates through an ArrayList of type Drug
 */
public class ArrayListIterator implements Iterator
{
    private ArrayList<Drug> list;
    private int pos;

    /**
     * A constructor that sets the list field to the list that is a parameter
     * 
     * @param list		An ArrayList of Drug objects 
     */
    public ArrayListIterator(ArrayList<Drug> list)
    {
        this.list = list;
        pos = 0;
    }

    /**
     * A Getter that returns the next Drug in the list and advances pos to it
     * 
     * @return			The drug in the list at pos
     */
    public Drug next()
    {
        Drug ob = list.get(pos);
        pos++;
        return ob;
    }

    /**
     * Checks if there is a next Drug object after pos in the list
     * 
     * @return 			A boolean value that indicates if there is a drug after pos
     */
    public boolean hasNext()
    {
        if(pos >= list.size())
            return false;
        return true;
    }
}

