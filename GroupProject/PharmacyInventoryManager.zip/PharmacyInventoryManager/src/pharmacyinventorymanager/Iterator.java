package pharmacyinventorymanager;

/**
 * Iterates through a data structure to traverse through each element.
 */
public interface Iterator 
{
	/**
	 * Progresses through the list to the next Drug object
	 * 
	 * @return			A drug object that is after the current position in the list
	 */
    public Object next();
    
    /**
     * Checks if the there is a Drug after the current position
     * 
     * @return			A boolean value that is true if there is a next Drug and false
     * 						if there is not
     */
    public boolean hasNext();
}
